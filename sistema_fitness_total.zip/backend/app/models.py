from datetime import datetime
from enum import Enum
from sqlalchemy import Column, Integer, String, DateTime, Boolean, Enum as SAEnum, ForeignKey, Text
from sqlalchemy.orm import relationship

from .database import Base

class UserType(str, Enum):
    PROFESSOR = "PROFESSOR"
    ALUNO = "ALUNO"

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    email = Column(String(100), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    type = Column(SAEnum(UserType), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    active = Column(Boolean, default=True)

    student = relationship("Student", back_populates="user", uselist=False)

class Student(Base):
    __tablename__ = "students"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    professor_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    notes = Column(Text, nullable=True)

    user = relationship("User", foreign_keys=[user_id], back_populates="student")
    professor = relationship("User", foreign_keys=[professor_id])

class ExerciseType(str, Enum):
    MUSCULACAO = "MUSCULACAO"
    CORRIDA = "CORRIDA"
    PEDAL = "PEDAL"
    OUTRO = "OUTRO"

class Exercise(Base):
    __tablename__ = "exercises"
    id = Column(Integer, primary_key=True, index=True)
    professor_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    name = Column(String(120), nullable=False)
    type = Column(SAEnum(ExerciseType), default=ExerciseType.MUSCULACAO)
    group = Column(String(120), nullable=True)
    description = Column(Text, nullable=True)
    tips = Column(Text, nullable=True)
    video_url = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    professor = relationship("User")

class TrainingPlan(Base):
    __tablename__ = "training_plans"
    id = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer, ForeignKey("students.id"), nullable=False)
    name = Column(String(120), nullable=False)
    goal = Column(Text, nullable=True)
    start_date = Column(DateTime, default=datetime.utcnow)
    end_date = Column(DateTime, nullable=True)
    notes = Column(Text, nullable=True)

    student = relationship("Student")
    sessions = relationship("TrainingSession", back_populates="plan")

class TrainingSession(Base):
    __tablename__ = "training_sessions"
    id = Column(Integer, primary_key=True, index=True)
    plan_id = Column(Integer, ForeignKey("training_plans.id"), nullable=False)
    name = Column(String(120), nullable=False)
    weekday = Column(String(20), nullable=True)
    main_type = Column(String(50), nullable=True)
    notes = Column(Text, nullable=True)

    plan = relationship("TrainingPlan", back_populates="sessions")
    items = relationship("TrainingSessionExercise", back_populates="session")

class TrainingSessionExercise(Base):
    __tablename__ = "training_session_exercises"
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("training_sessions.id"), nullable=False)
    exercise_id = Column(Integer, ForeignKey("exercises.id"), nullable=False)
    order = Column(Integer, default=1)
    params = Column(Text, nullable=True)  # JSON em string simples para MVP
    notes = Column(Text, nullable=True)

    session = relationship("TrainingSession", back_populates="items")
    exercise = relationship("Exercise")

class ExecutionStatus(str, Enum):
    CONCLUIDO = "CONCLUIDO"
    PARCIAL = "PARCIAL"
    NAO_REALIZADO = "NAO_REALIZADO"

class TrainingExecution(Base):
    __tablename__ = "training_executions"
    id = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer, ForeignKey("students.id"), nullable=False)
    session_id = Column(Integer, ForeignKey("training_sessions.id"), nullable=False)
    executed_at = Column(DateTime, default=datetime.utcnow)
    status = Column(SAEnum(ExecutionStatus), default=ExecutionStatus.CONCLUIDO)
    rpe = Column(Integer, nullable=True)
    comment = Column(Text, nullable=True)

    student = relationship("Student")
    session = relationship("TrainingSession")

class ExerciseExecution(Base):
    __tablename__ = "exercise_executions"
    id = Column(Integer, primary_key=True, index=True)
    training_execution_id = Column(Integer, ForeignKey("training_executions.id"), nullable=False)
    session_exercise_id = Column(Integer, ForeignKey("training_session_exercises.id"), nullable=False)
    data = Column(Text, nullable=True)  # JSON em string
    notes = Column(Text, nullable=True)

    training_execution = relationship("TrainingExecution")
    session_exercise = relationship("TrainingSessionExercise")
