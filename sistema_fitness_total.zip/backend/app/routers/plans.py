from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import TrainingPlan, TrainingSession, User, UserType, Student
from ..schemas import TrainingPlanCreate, TrainingPlanOut, TrainingSessionCreate, TrainingSessionOut
from ..core.security import get_current_user

router = APIRouter()

@router.post("/", response_model=TrainingPlanOut)
def create_plan(payload: TrainingPlanCreate, db: Session = Depends(get_db), current: User = Depends(get_current_user)):
    if current.type != UserType.PROFESSOR:
        raise HTTPException(status_code=403, detail="Apenas professor pode criar planos")
    student = db.get(Student, payload.student_id)
    if not student:
        raise HTTPException(status_code=404, detail="Aluno não encontrado")
    plan = TrainingPlan(
        student_id=payload.student_id,
        name=payload.name,
        goal=payload.goal,
        start_date=payload.start_date,
        end_date=payload.end_date,
        notes=payload.notes,
    )
    db.add(plan)
    db.commit()
    db.refresh(plan)
    return plan

@router.get("/aluno/{student_id}", response_model=List[TrainingPlanOut])
def list_plans(student_id: int, db: Session = Depends(get_db), current: User = Depends(get_current_user)):
    q = db.query(TrainingPlan).filter_by(student_id=student_id)
    return q.all()

@router.post("/sessao", response_model=TrainingSessionOut)
def create_session(payload: TrainingSessionCreate, db: Session = Depends(get_db), current: User = Depends(get_current_user)):
    if current.type != UserType.PROFESSOR:
        raise HTTPException(status_code=403, detail="Apenas professor pode criar sessões")
    plan = db.get(TrainingPlan, payload.plan_id)
    if not plan:
        raise HTTPException(status_code=404, detail="Plano não encontrado")
    session = TrainingSession(
        plan_id=payload.plan_id,
        name=payload.name,
        weekday=payload.weekday,
        main_type=payload.main_type,
        notes=payload.notes,
    )
    db.add(session)
    db.commit()
    db.refresh(session)
    return session

@router.get("/sessao/{plan_id}", response_model=List[TrainingSessionOut])
def list_sessions(plan_id: int, db: Session = Depends(get_db), current: User = Depends(get_current_user)):
    q = db.query(TrainingSession).filter_by(plan_id=plan_id)
    return q.all()
