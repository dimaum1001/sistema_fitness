from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Exercise, User, UserType
from ..schemas import ExerciseCreate, ExerciseOut
from ..core.security import get_current_user

router = APIRouter()

@router.get("/", response_model=List[ExerciseOut])
def list_exercises(db: Session = Depends(get_db), current: User = Depends(get_current_user)):
    # Professor vê só dele, aluno vê todos do professor vinculado (simplificado para MVP)
    if current.type == UserType.PROFESSOR:
        q = db.query(Exercise).filter(
            (Exercise.professor_id == current.id) | (Exercise.professor_id.is_(None))
        )
    else:
        q = db.query(Exercise)
    return q.all()

@router.post("/", response_model=ExerciseOut)
def create_exercise(payload: ExerciseCreate, db: Session = Depends(get_db), current: User = Depends(get_current_user)):
    if current.type != UserType.PROFESSOR:
        raise HTTPException(status_code=403, detail="Apenas professor pode cadastrar exercícios")
    ex = Exercise(
        professor_id=current.id,
        name=payload.name,
        type=payload.type,
        group=payload.group,
        description=payload.description,
        tips=payload.tips,
        video_url=payload.video_url,
    )
    db.add(ex)
    db.commit()
    db.refresh(ex)
    return ex

@router.get("/{exercise_id}/explicacao", response_model=ExerciseOut)
def explain_exercise(exercise_id: int, db: Session = Depends(get_db), current: User = Depends(get_current_user)):
    ex = db.get(Exercise, exercise_id)
    if not ex:
        raise HTTPException(status_code=404, detail="Exercício não encontrado")
    return ex
