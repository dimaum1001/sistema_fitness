from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import TrainingExecution, User, UserType
from ..schemas import TrainingExecutionCreate, TrainingExecutionOut
from ..core.security import get_current_user

router = APIRouter()

@router.post("/", response_model=TrainingExecutionOut)
def create_execution(payload: TrainingExecutionCreate, db: Session = Depends(get_db), current: User = Depends(get_current_user)):
    if current.type != UserType.ALUNO:
        # Professor pode registrar manualmente também, se quiser – aqui deixamos aberto
        pass
    execu = TrainingExecution(
        student_id=payload.student_id,
        session_id=payload.session_id,
        status=payload.status,
        rpe=payload.rpe,
        comment=payload.comment,
    )
    db.add(execu)
    db.commit()
    db.refresh(execu)
    return execu

@router.get("/aluno/{student_id}", response_model=List[TrainingExecutionOut])
def list_executions(student_id: int, db: Session = Depends(get_db), current: User = Depends(get_current_user)):
    q = db.query(TrainingExecution).filter_by(student_id=student_id)
    return q.all()
