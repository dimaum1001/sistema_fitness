from fastapi import APIRouter
from . import auth, exercises, plans, executions

api_router = APIRouter()
api_router.include_router(auth.router, prefix="/auth", tags=["auth"])
api_router.include_router(exercises.router, prefix="/exercicios", tags=["exercicios"])
api_router.include_router(plans.router, prefix="/planos", tags=["planos"])
api_router.include_router(executions.router, prefix="/execucoes", tags=["execucoes"])
