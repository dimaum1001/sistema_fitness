from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, EmailStr

from .models import UserType, ExerciseType, ExecutionStatus

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class UserBase(BaseModel):
    name: str
    email: EmailStr

class UserCreate(UserBase):
    password: str
    type: UserType

class UserOut(UserBase):
    id: int
    type: UserType
    class Config:
        from_attributes = True

class ExerciseBase(BaseModel):
    name: str
    type: ExerciseType = ExerciseType.MUSCULACAO
    group: Optional[str] = None
    description: Optional[str] = None
    tips: Optional[str] = None
    video_url: Optional[str] = None

class ExerciseCreate(ExerciseBase):
    pass

class ExerciseOut(ExerciseBase):
    id: int
    class Config:
        from_attributes = True

class TrainingPlanBase(BaseModel):
    name: str
    goal: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    notes: Optional[str] = None

class TrainingPlanCreate(TrainingPlanBase):
    student_id: int

class TrainingPlanOut(TrainingPlanBase):
    id: int
    class Config:
        from_attributes = True

class TrainingSessionBase(BaseModel):
    name: str
    weekday: Optional[str] = None
    main_type: Optional[str] = None
    notes: Optional[str] = None

class TrainingSessionCreate(TrainingSessionBase):
    plan_id: int

class TrainingSessionOut(TrainingSessionBase):
    id: int
    class Config:
        from_attributes = True

class TrainingExecutionBase(BaseModel):
    student_id: int
    session_id: int
    status: ExecutionStatus = ExecutionStatus.CONCLUIDO
    rpe: Optional[int] = None
    comment: Optional[str] = None

class TrainingExecutionCreate(TrainingExecutionBase):
    pass

class TrainingExecutionOut(TrainingExecutionBase):
    id: int
    executed_at: datetime
    class Config:
        from_attributes = True
