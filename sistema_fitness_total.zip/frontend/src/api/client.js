const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';

async function request(path, options = {}) {
  const token = localStorage.getItem('token');
  const headers = options.headers || {};
  if (!(options.body instanceof FormData)) {
    headers['Content-Type'] = headers['Content-Type'] || 'application/json';
  }
  if (token) headers['Authorization'] = `Bearer ${token}`;
  const res = await fetch(`${API_URL}${path}`, { ...options, headers });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || 'Erro na requisição');
  }
  return res.json();
}

export function login(email, password) {
  const data = new URLSearchParams();
  data.append('username', email);
  data.append('password', password);
  return fetch(`${API_URL}/auth/login`, {
    method: 'POST',
    body: data
  }).then(async (res) => {
    if (!res.ok) throw new Error('Login inválido');
    return res.json();
  });
}

export function getMe() {
  return request('/auth/me');
}

export function getExercises() {
  return request('/exercicios');
}
