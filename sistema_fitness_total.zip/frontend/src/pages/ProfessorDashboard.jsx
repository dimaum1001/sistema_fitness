import { useEffect, useState } from 'react';
import Navbar from '../components/Navbar.jsx';
import { getExercises } from '../api/client.js';

export default function ProfessorDashboard() {
  const [exercises, setExercises] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const data = await getExercises();
        setExercises(data);
      } catch (err) {
        setError('Erro ao carregar exercícios');
      }
    })();
  }, []);

  return (
    <div>
      <Navbar />
      <main className="max-w-4xl mx-auto px-4">
        <h1 className="text-2xl font-semibold mb-4">Dashboard do Professor</h1>
        <p className="mb-4 text-sm text-gray-600">
          Aqui você verá um resumo dos treinos dos seus alunos. No MVP, mostramos apenas a lista de exercícios cadastrados.
        </p>
        {error && <p className="text-red-600 mb-3 text-sm">{error}</p>}
        <div className="bg-white shadow rounded p-4">
          <h2 className="font-semibold mb-2">Exercícios cadastrados</h2>
          <ul className="space-y-1 text-sm">
            {exercises.map((ex) => (
              <li key={ex.id} className="border-b last:border-none py-1">
                <span className="font-medium">{ex.name}</span> {' '}
                <span className="text-xs text-gray-500">({ex.type})</span>
              </li>
            ))}
            {exercises.length === 0 && (
              <li className="text-xs text-gray-500">Nenhum exercício cadastrado ainda.</li>
            )}
          </ul>
        </div>
      </main>
    </div>
  );
}
