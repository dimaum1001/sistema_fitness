import { useEffect, useState } from 'react';
import Navbar from '../components/Navbar.jsx';
import { getExercises } from '../api/client.js';

export default function AlunoDashboard() {
  const [exercises, setExercises] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const data = await getExercises();
        setExercises(data);
      } catch (err) {
        setError('Erro ao carregar exercícios');
      }
    })();
  }, []);

  return (
    <div>
      <Navbar />
      <main className="max-w-4xl mx-auto px-4">
        <h1 className="text-2xl font-semibold mb-4">Dashboard do Aluno</h1>
        <p className="mb-4 text-sm text-gray-600">
          No MVP, mostramos uma "lista de referência" de exercícios cadastrados pelo seu professor.
          Em versões futuras, aqui aparecerá seu treino do dia e da semana.
        </p>
        {error && <p className="text-red-600 mb-3 text-sm">{error}</p>}
        <div className="bg-white shadow rounded p-4">
          <h2 className="font-semibold mb-2">Biblioteca de exercícios</h2>
          <ul className="space-y-1 text-sm">
            {exercises.map((ex) => (
              <li key={ex.id} className="border-b last:border-none py-1">
                <div className="font-medium">{ex.name}</div>
                {ex.description && (
                  <div className="text-xs text-gray-600">{ex.description}</div>
                )}
              </li>
            ))}
            {exercises.length === 0 && (
              <li className="text-xs text-gray-500">Nenhum exercício disponível ainda.</li>
            )}
          </ul>
        </div>
      </main>
    </div>
  );
}
