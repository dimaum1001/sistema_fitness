# Sistema Fitness Total

MVP em modo skeleton, com backend FastAPI e frontend React + Vite + Tailwind.

## Estrutura

- backend/
  - app/
    - main.py
    - database.py
    - models.py
    - schemas.py
    - routers/
    - core/
- frontend/
  - Vite + React + Tailwind

Veja instruções rápidas em cada README futuro que você possa criar.
